# aDiB 9Router + Hermes Agent

A deployment-ready Docker Compose bundle for running:

- 9Router
- Hermes Agent Gateway
- Telegram integration
- Persistent data
- Internal Docker networking
- Optional routing of Hermes through 9Router

The upstream projects are used as published Docker images; this repository
contains only deployment/configuration glue.

## Architecture

```text
Telegram
   |
   v
Hermes Agent
   |
   | OpenAI-compatible API
   v
9Router
   |
   +--> configured LLM providers
```

Both services are persistent and communicate over the private Docker network.

## 1. Local / VPS deployment

```bash
cp .env.example .env
```

Edit `.env` and set at least:

```env
NINEROUTER_INITIAL_PASSWORD=your-strong-password
NINEROUTER_JWT_SECRET=long-random-secret
NINEROUTER_API_KEY_SECRET=long-random-secret
NINEROUTER_MACHINE_ID_SALT=long-random-secret

TELEGRAM_BOT_TOKEN=123456:ABC...
TELEGRAM_ALLOWED_USERS=123456789
```

Then:

```bash
docker compose up -d
docker compose ps
docker compose logs -f
```

9Router is internally available at:

```text
http://9router:20128
```

Hermes is internally configured to use:

```text
http://9router:20128/v1
```

### Important: 9Router API key

`NINEROUTER_API_KEY_SECRET` is NOT the same thing as a 9Router endpoint
API key.

If your 9Router configuration requires endpoint authentication, create an
endpoint API key in the 9Router dashboard and put the resulting key in:

```env
NINEROUTER_API_KEY=...
```

Do not commit that value.

## 2. Telegram

Hermes uses:

```env
TELEGRAM_BOT_TOKEN=
TELEGRAM_ALLOWED_USERS=
```

`TELEGRAM_ALLOWED_USERS` is the numeric Telegram user ID allowed to control
the bot.

A separate "bot ID" normally does not need to be configured: Telegram
identifies the bot through `TELEGRAM_BOT_TOKEN`.

For multiple users:

```env
TELEGRAM_ALLOWED_USERS=123456789,987654321
```

Keep this allowlist restrictive.

## 3. Railway

Railway can deploy Dockerfiles from GitHub and can import Compose services,
but Compose services become separate Railway services. They do not run
docker-compose.yml as one Docker container.

Recommended Railway layout:

```text
Railway Project
├── 9router service
└── Hermes service
```

### 9Router service

Deploy the `decolua/9router:latest` Docker image.

Set variables:

```env
PORT=20128
DATA_DIR=/app/data
NODE_ENV=production
JWT_SECRET=...
INITIAL_PASSWORD=...
API_KEY_SECRET=...
MACHINE_ID_SALT=...
```

Attach a Railway Volume to:

```text
/app/data
```

Generate a public domain if you need to access the 9Router dashboard/API
from the Internet.

### Hermes service

Deploy the `nousresearch/hermes-agent:latest` Docker image.

Command:

```text
gateway run
```

Set:

```env
TELEGRAM_BOT_TOKEN=...
TELEGRAM_ALLOWED_USERS=...
OPENAI_BASE_URL=http://9router.railway.internal:20128/v1
OPENAI_API_KEY=...
HERMES_DASHBOARD_HOST=0.0.0.0
HERMES_DASHBOARD_PORT=9119
```

Use the actual Railway private hostname shown by Railway for the 9Router
service if it differs from the example above.

Attach a separate Railway Volume to:

```text
/opt/data
```

Do NOT share the same volume between 9Router and Hermes.

## 4. Security

Never commit:

- `.env`
- Telegram bot token
- LLM API keys
- 9Router endpoint API keys
- JWT secrets
- Hermes credentials

For a public deployment, use HTTPS and protect the Hermes dashboard.
Do not expose an unauthenticated dashboard directly to the Internet.

## 5. Updates

The images are intentionally referenced by `:latest` for easy deployment.

For a production deployment where reproducibility matters, pin image
versions/digests after validating a release.

## Upstream projects

9Router:
https://github.com/decolua/9router

Hermes Agent:
https://github.com/NousResearch/hermes-agent
