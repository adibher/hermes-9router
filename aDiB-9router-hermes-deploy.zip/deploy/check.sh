#!/usr/bin/env bash
set -euo pipefail

echo "== aDiB 9Router + Hermes preflight =="

command -v docker >/dev/null || { echo "Docker is required."; exit 1; }
docker compose version >/dev/null || { echo "Docker Compose is required."; exit 1; }

if [[ ! -f .env ]]; then
  echo "Missing .env"
  echo "Run: cp .env.example .env"
  exit 1
fi

required=(
  NINEROUTER_INITIAL_PASSWORD
  NINEROUTER_JWT_SECRET
  NINEROUTER_API_KEY_SECRET
  NINEROUTER_MACHINE_ID_SALT
  TELEGRAM_BOT_TOKEN
  TELEGRAM_ALLOWED_USERS
)

for key in "${required[@]}"; do
  value="$(grep -E "^${key}=" .env | head -n1 | cut -d= -f2- || true)"
  if [[ -z "$value" || "$value" == "CHANGE_ME"* ]]; then
    echo "Missing/placeholder: $key"
    exit 1
  fi
done

echo "Configuration looks valid."
echo "Start with: docker compose up -d"
